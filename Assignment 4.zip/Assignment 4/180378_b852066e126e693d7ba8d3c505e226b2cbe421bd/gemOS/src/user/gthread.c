#include <gthread.h>
#include <ulib.h>

static struct process_thread_info tinfo __attribute__((section(".user_data"))) = {};
/*XXX 
      Do not modifiy anything above this line. The global variable tinfo maintains user
      level accounting of threads. Refer gthread.h for definition of related structs.
 */


void normal_exit(){
	void* retval;
	// assembly code to store the address of the return value to the retval
	asm volatile("mov %%rax, %0" : "=r" (retval):);
	gthread_exit(retval);
	return;
}

/* Returns 0 on success and -1 on failure */
/* Here you can use helper system call "make_thread_ready" for your implementation */
int gthread_create(int *tid, void *(*fc)(void *), void *arg) {
        
	/* You need to fill in your implementation here*/
	void *thread_stack = mmap(NULL, TH_STACK_SIZE, PROT_READ|PROT_WRITE, 0);
	
	if(!thread_stack || thread_stack == MAP_ERR){
        return -1;
  	}
	
	void* head = (void*)(((u64)thread_stack) + TH_STACK_SIZE - 8);
	*(u64 *)head = (u64)(&normal_exit);
	
	long thpid = clone(fc, (u64)head, arg);
	
	if(thpid <= 0){
       	return -1;
	}

	int curr_thread_num = 0;
	while(curr_thread_num < MAX_THREADS){
		if(tinfo.threads[curr_thread_num].pid == 0){
			break;
		}
		else{
			curr_thread_num++;
		}
	}
	if(curr_thread_num >= MAX_THREADS){
		return -1;
	}

	
	tinfo.threads[curr_thread_num].pid = thpid;
	tinfo.threads[curr_thread_num].tid = tinfo.num_threads;
	tinfo.threads[curr_thread_num].status = TH_STATUS_ALIVE;
	tinfo.threads[curr_thread_num].stack_addr = thread_stack;
	*tid = tinfo.num_threads;
	tinfo.num_threads = tinfo.num_threads + 1;

	make_thread_ready(thpid);
	// printf("Created Successfully");
	return thpid;

	return -1;
}

int gthread_exit(void *retval) {

	/* You need to fill in your implementation here*/
	// printf("Entered Gthread Exit\n");
	int thpid = getpid();
	int curr_thread_num = 0;
	while(curr_thread_num < MAX_THREADS){
		if(tinfo.threads[curr_thread_num].pid == thpid){
			break;
		}
		curr_thread_num++;
	}
	tinfo.threads[curr_thread_num].status = TH_STATUS_USED;
	tinfo.threads[curr_thread_num].ret_addr = retval;
	exit(0);
}

void* gthread_join(int tid) {
     /* Here you can use helper system call "wait_for_thread" for your implementation */
		int curr_thread_num = 0;
		while(curr_thread_num < MAX_THREADS){
			if(tinfo.threads[curr_thread_num].tid == tid){
				break;
			}
			curr_thread_num++;
		}
		int temp = 0;
		while(tinfo.threads[curr_thread_num].status == TH_STATUS_ALIVE && temp >= 0){
			temp = wait_for_thread(tinfo.threads[curr_thread_num].pid);
		}
		if(munmap(tinfo.threads[curr_thread_num].stack_addr,TH_STACK_SIZE) < 0){
			return NULL;
		}
		void* final = tinfo.threads[curr_thread_num].ret_addr;
		tinfo.threads[curr_thread_num].pid = 0;
		tinfo.threads[curr_thread_num].status = TH_STATUS_USED;
		tinfo.threads[curr_thread_num].tid = -1;
		tinfo.threads[curr_thread_num].stack_addr = NULL;
		tinfo.threads[curr_thread_num].ret_addr = NULL; 
		tinfo.num_threads = tinfo.num_threads - 1;

	return final;
}


/*Only threads will invoke this. No need to check if its a process
 * The allocation size is always < GALLOC_MAX and flags can be one
 * of the alloc flags (GALLOC_*) defined in gthread.h. Need to 
 * invoke mmap using the proper protection flags (for prot param to mmap)
 * and MAP_TH_PRIVATE as the flag param of mmap. The mmap call will be 
 * handled by handle_thread_private_map in the OS.
 * */

void* gmalloc(u32 size, u8 alloc_flag)
{
   
	/* You need to fill in your implementation here*/
	long thpid = getpid();
	struct thread_info* curr_thread = NULL;
	for(int i = 0;i<MAX_THREADS;i++){
		if(tinfo.threads[i].pid = thpid){
			curr_thread = &tinfo.threads[i];
			break;
		}
	}
	if(curr_thread == NULL){
		return NULL;
	}
	struct galloc_area* new_priv_area = NULL;
	for(int i = 0;i < MAX_GALLOC_AREAS ;i++){
		if(curr_thread->priv_areas[i].owner == NULL){
			new_priv_area = &curr_thread->priv_areas[i];
			break;
		}
	}
	if(new_priv_area == NULL){
		return NULL;
	}
	new_priv_area->owner = curr_thread;
	new_priv_area->length = size;

	if(alloc_flag == GALLOC_OWNONLY){
		new_priv_area->start = (u64) mmap(NULL, size, PROT_READ | PROT_WRITE | TP_SIBLINGS_NOACCESS, MAP_TH_PRIVATE);
		new_priv_area->flags = TP_SIBLINGS_NOACCESS;
	}
	else if(alloc_flag == GALLOC_OTRDONLY){
		new_priv_area->start = (u64) mmap(NULL, size, PROT_READ | PROT_WRITE | TP_SIBLINGS_RDONLY, MAP_TH_PRIVATE);
		new_priv_area->flags = TP_SIBLINGS_RDONLY;
	}
	else if(alloc_flag == GALLOC_OTRDWR){
		new_priv_area->start = (u64) mmap(NULL, size, PROT_READ | PROT_WRITE | TP_SIBLINGS_RDWR, MAP_TH_PRIVATE);
		new_priv_area->flags = TP_SIBLINGS_RDWR;
	}
	else{
		return NULL;
	}
	// printf("Gmalloc called and allocated\n");
	return (void *)new_priv_area->start;
	
}
/*
   Only threads will invoke this. No need to check if the caller is a process.
*/
int gfree(void *ptr)
{
   
    /* You need to fill in your implementation here*/
		long thpid = getpid();
		struct thread_info* curr_thread = NULL;
		for(int i = 0; i<MAX_THREADS; i++){
			if(tinfo.threads[i].pid == thpid){
				curr_thread = &tinfo.threads[i];
				break;
			}
		}
		if(curr_thread == NULL){
			return -1;
		}
		struct galloc_area* priv_area = NULL;
		for(int i = 0;i<MAX_GALLOC_AREAS;i++){
			if(curr_thread->priv_areas[i].start = (u64)ptr){
				priv_area = &curr_thread->priv_areas[i];
				break;
			}
		}
		if(priv_area == NULL){
			return -1;
		}
		if(munmap((void*)priv_area->start,priv_area->length) < 0){
			return -1;
		}
		priv_area->owner = NULL;
		priv_area->length = 0;
		priv_area->start = 0;
		priv_area->flags = 0;
		
     	return 0;
}
