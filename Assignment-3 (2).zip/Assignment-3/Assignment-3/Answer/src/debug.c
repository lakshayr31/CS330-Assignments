#include <debug.h>
#include <context.h>
#include <entry.h>
#include <lib.h>
#include <memory.h>


/*****************************HELPERS******************************************/

/*
 * allocate the struct which contains information about debugger
 *
 */
struct debug_info *alloc_debug_info()
{
	struct debug_info *info = (struct debug_info *) os_alloc(sizeof(struct debug_info));
	if(info)
		bzero((char *)info, sizeof(struct debug_info));
	return info;
}
/*
 * frees a debug_info struct
 */
void free_debug_info(struct debug_info *ptr)
{
	if(ptr)
		os_free((void *)ptr, sizeof(struct debug_info));
}



/*
 * allocates a page to store registers structure
 */
struct registers *alloc_regs()
{
	struct registers *info = (struct registers*) os_alloc(sizeof(struct registers));
	if(info)
		bzero((char *)info, sizeof(struct registers));
	return info;
}

/*
 * frees an allocated registers struct
 */
void free_regs(struct registers *ptr)
{
	if(ptr)
		os_free((void *)ptr, sizeof(struct registers));
}

/*
 * allocate a node for breakpoint list
 * which contains information about breakpoint
 */
struct breakpoint_info *alloc_breakpoint_info()
{
	struct breakpoint_info *info = (struct breakpoint_info *)os_alloc(
		sizeof(struct breakpoint_info));
	if(info)
		bzero((char *)info, sizeof(struct breakpoint_info));
	return info;
}

/*
 * frees a node of breakpoint list
 */
void free_breakpoint_info(struct breakpoint_info *ptr)
{
	if(ptr)
		os_free((void *)ptr, sizeof(struct breakpoint_info));
}

/*
 * Fork handler.
 * The child context doesnt need the debug info
 * Set it to NULL
 * The child must go to sleep( ie move to WAIT state)
 * It will be made ready when the debugger calls wait
 */
void debugger_on_fork(struct exec_context *child_ctx)
{
	// printk("DEBUGGER FORK HANDLER CALLED\n");
	child_ctx->dbg = NULL;
	child_ctx->state = WAITING;
}


/******************************************************************************/


/* This is the int 0x3 handler
 * Hit from the childs context
 */
int addToCallStack(struct exec_context* ctx){

	struct exec_context* parent = get_ctx_by_pid(ctx->ppid);
	int count = parent->dbg->callStackCount;

	if(count >= MAX_BACKTRACE){
		return -1;
	}

	u64 *callStackArr = parent->dbg->callStack;

	u64 addr = ctx->regs.entry_rip - 1;
	callStackArr[count] = addr;

	parent->dbg->callStackCount++;
	return 0;
}

void removeFromCallStack(struct exec_context* ctx){
	struct exec_context* parent = get_ctx_by_pid(ctx->ppid);
	int count = parent->dbg->callStackCount-1;

	u64 *callStackArr = (u64 *)parent->dbg->callStack;
	// find the latest one which has set enable to be 1; and remove all till that function and the function itself.
	for(int i = count; i >= 0 ; i--){
		u64 addr = callStackArr[count];
		struct breakpoint_info *bp = parent->dbg->head;
		while(bp != NULL){
			if(bp->addr == addr){
				break;
			}
			bp = bp->next;
		}
		callStackArr[count] = -1;
		count--;
		parent->dbg->callStackCount--;
		if(bp->end_breakpoint_enable == 1){
			break;
		}
	}
}

void copyRegs(struct exec_context* parent, struct exec_context* ctx){
	
	parent->dbg->regs.r15 = ctx->regs.r15;
	parent->dbg->regs.r14 = ctx->regs.r14;
	parent->dbg->regs.r13 = ctx->regs.r13;
	parent->dbg->regs.r12 = ctx->regs.r12;
	parent->dbg->regs.r11 = ctx->regs.r11;
	parent->dbg->regs.r10 = ctx->regs.r10;
	parent->dbg->regs.r9 = ctx->regs.r9;
	parent->dbg->regs.r8 = ctx->regs.r8;
	parent->dbg->regs.rbp = ctx->regs.rbp;
	parent->dbg->regs.rdi = ctx->regs.rdi;
	parent->dbg->regs.rsi = ctx->regs.rsi;
	parent->dbg->regs.rdx = ctx->regs.rdx;
	parent->dbg->regs.rcx = ctx->regs.rcx;
	parent->dbg->regs.rbx = ctx->regs.rbx;
	parent->dbg->regs.rax = ctx->regs.rax;
	parent->dbg->regs.entry_rsp = ctx->regs.entry_rsp;
	parent->dbg->regs.entry_rip = ctx->regs.entry_rip - 1;
	parent->dbg->regs.entry_cs = ctx->regs.entry_cs;
	parent->dbg->regs.entry_rflags = ctx->regs.entry_rflags;
	parent->dbg->regs.entry_ss = ctx->regs.entry_ss;

}

void setTraceArray(struct exec_context *ctx, int fromEnd){
	int count = 0;
	struct exec_context *parent = get_ctx_by_pid(ctx->ppid);
	u64 *traceArray = parent->dbg->backtraceArray;
	if(!fromEnd){
		traceArray[count] = ctx->regs.entry_rip - 1;
		count++;
	}

	u64 currAddr = ctx->regs.entry_rsp;
	u64 baseAddr = ctx->regs.rbp;
	int returnCount = parent->dbg->returnCount - 1;
	while(*(u64 *)currAddr != END_ADDR){
		if(*(u64*)currAddr == (u64)parent->dbg->end_handler){
			traceArray[count] = parent->dbg->returnAddr[returnCount];
			returnCount--;
		}
		else{
			traceArray[count] = *(u64 *)currAddr;
		}
		currAddr = baseAddr + 8;
		baseAddr = *(u64 *)baseAddr;
		count++;
	}
	parent->dbg->backTraceCount = count;
}

int presentOnStack(u64 addr, struct exec_context* ctx){
	u64 *callStackArr = ctx->dbg->callStack;
	int count = ctx->dbg->callStackCount-1;
	while(count >= 0){
		if(callStackArr[count] == addr){
			return 1;
		}
		count--;
	}
	return 0;
}

long int3_handler(struct exec_context *ctx)
{
	
	//Your code
	// when this is entered then first we will have to store the registers states
	// because they point to the registers of the process, and they might change when we work with this handler
	
	if(ctx == NULL) return -1;
	
	//stimulates the push rbp instruction before returning
	// ** have to add a check if this is from breakpoint or from the do end handler //
	struct exec_context* parent = get_ctx_by_pid(ctx->ppid);
	if(parent->dbg == NULL) return -1;
	int fromEnd = 0;
	u64 currBreakpointAddr = ctx->regs.entry_rip; // check if this gives the adress inside the entry_rip
	currBreakpointAddr -= 1; // from rip register you get the next address of the function, call, the function address is one less than that
	
	if(currBreakpointAddr == (u64)parent->dbg->end_handler){
		fromEnd = 1;
	}
	if(fromEnd == 0){
		struct breakpoint_info* currBreakpoint = NULL;
		struct breakpoint_info* breakpointHead = parent->dbg->head;
		
		while(breakpointHead->addr != currBreakpointAddr){
			breakpointHead = breakpointHead->next;
		}
		
		currBreakpoint = breakpointHead;
		if(currBreakpoint->end_breakpoint_enable == 0){
			// IF FROM BREAKPOINT AND HAS SET IS NOT ENABLED
			copyRegs(parent, ctx);
			setTraceArray(ctx,fromEnd);
			if(addToCallStack(ctx) == -1) return -1;
			ctx->regs.entry_rsp -= 8;
			u64 head = ctx->regs.entry_rsp;
			*(u64 *)head = ctx->regs.rbp;
		}
		else{
			// IF BREAK POINT ENABLE IS SET TO 1
			copyRegs(parent, ctx);
			setTraceArray(ctx,fromEnd);
			if(addToCallStack(ctx) == -1) return -1;

			parent->dbg->returnAddr[parent->dbg->returnCount] = *(u64*) (ctx->regs.entry_rsp);
			parent->dbg->returnCount++;
			// printk("Current Return Address %x\n", *(u64 *)ctx->regs.entry_rsp);
			// ctx->regs.entry_rsp -= 8;
			u64 newReturnAddress = ctx->regs.entry_rsp;
			*(u64 *)newReturnAddress = (u64 )parent->dbg->end_handler;
			// printk("Current Return Address After Adding Debug Handler %x", *(u64 *)ctx->regs.entry_rsp);
			ctx->regs.entry_rsp -= 8;
			u64 head = ctx->regs.entry_rsp;
			*(u64 *)head = ctx->regs.rbp;
			// printk("Current Return Address After adding RBP %x", *(u64 *)ctx->regs.entry_rsp);
			// printk("Original address %x", *(u64 *)(ctx->regs.entry_rsp + 16));
		}
	}
	else{
		// IF FROM END POINT
		// printk("Reached INT3\n");
		ctx->regs.entry_rsp -= 8;
		u64 newReturnAddress = ctx->regs.entry_rsp;
		parent->dbg->returnCount--;		
		*(u64 *)newReturnAddress = (u64)parent->dbg->returnAddr[parent->dbg->returnCount];
		copyRegs(parent, ctx);
		setTraceArray(ctx,fromEnd);	
		removeFromCallStack(ctx);
		ctx->regs.entry_rsp -= 8;
		u64 head = ctx->regs.entry_rsp;
		*(u64 *)head = ctx->regs.rbp;
	}
	
	parent->regs.rax = ctx->regs.entry_rip - 1;

	ctx->state = WAITING;
	parent->state = READY;
	schedule(parent);
	return -1;
}

/*
 * Exit handler.
 * Deallocate the debug_info struct if its a debugger.
 * Wake up the debugger if its a child
 */
void debugger_on_exit(struct exec_context *ctx)
{
	// Your code
	if(ctx->dbg == NULL){
		struct exec_context* parent = get_ctx_by_pid(ctx->ppid);
		parent->state = READY;
		return;
	}
	else{
		struct breakpoint_info *head = ctx->dbg->head;
		while(head!=NULL){
			struct breakpoint_info* curr = head->next;
			head->next = NULL;
			free_breakpoint_info(head);
			head = curr;
		}
		free_debug_info(ctx->dbg);
		ctx->dbg = NULL;
		return;
	}
}

/*
 * called from debuggers context
 * initializes debugger state
 */
int do_become_debugger(struct exec_context *ctx, void *addr)
{

	if(ctx == NULL) return -1;

	ctx->dbg = alloc_debug_info();
	
	if(ctx->dbg == NULL){
		return -1;
	}
	
	ctx->dbg->breakpoint_count = 0;
	ctx->dbg->end_handler = addr;
	ctx->dbg->head = NULL;
	ctx->dbg->set_break_count = 0;
	ctx->dbg->backTraceCount = 0;
	ctx->dbg->callStackCount = 0;
	ctx->dbg->returnCount = 0;
	
	*(unsigned char*)ctx->dbg->end_handler = INT3_OPCODE;
	// printk("Instruction at debug handler : %x \n", *(unsigned char *)ctx->dbg->end_handler);
	return 0;
}

/*
 * called from debuggers context
 */
int do_set_breakpoint(struct exec_context *ctx, void *addr, int flag)
{

	// Your code
	// set the breakpoint on the debugee's process at address add -> manipulate the address space so that the instruction at addr is executed, then INT3 is triggered
	// if lag is set the see how to add the breakpoint for the do handler to execute at the end -> save the flaf in en_brakepoint_enable memebr inside struct breakpoint_info
	// save the breakpoint information -> address, end_breakpoint flag and breakpoint number, in parent processes's execution context
	

	// saving the relevant information

	if(ctx == NULL || ctx->dbg == NULL){
		return -1;
	}
	if(addr == NULL){
		return -1;
	}

	struct breakpoint_info *curr_breakpoint = ctx->dbg->head;
	
	if(curr_breakpoint != NULL){
		struct breakpoint_info *prev;
		while(curr_breakpoint != NULL){
			prev = curr_breakpoint;
			if(prev->addr == (u64)addr){
				int present = presentOnStack((u64)addr,ctx);
				if(present){
					if(prev->end_breakpoint_enable == flag){
						return 0;
					}
					else{
						if(prev->end_breakpoint_enable == 0 && flag == 1){
							prev->end_breakpoint_enable = 1;
							return 0;	
						}
						else {
							return -1;
						}
					}
				}
				else {
					prev->end_breakpoint_enable = flag;
					return 0;
				}
			}
			curr_breakpoint = curr_breakpoint->next;
		}
		curr_breakpoint = prev;
	}

	if(ctx->dbg->breakpoint_count == MAX_BREAKPOINTS){
		return -1;
	}

	struct breakpoint_info *new_breakpoint = alloc_breakpoint_info();
	if(new_breakpoint == NULL) return -1;
	

	if(ctx->dbg->head == NULL){
		ctx->dbg->head = new_breakpoint;
	}
	else{
		curr_breakpoint->next = new_breakpoint;
	}

	new_breakpoint->addr = (u64) addr;
	new_breakpoint->end_breakpoint_enable = flag;
	new_breakpoint->next = NULL;
	new_breakpoint->num = ctx->dbg->breakpoint_count;
	*(unsigned char*)addr = INT3_OPCODE; // changes the debugee's address space

	ctx->dbg->breakpoint_count++;
	ctx->dbg->set_break_count++;

	return 0;
}

/*
 * called from debuggers context
 */
int do_remove_breakpoint(struct exec_context *ctx, void *addr)
{
	//Your code
	// find the breakpoint present at this address
	// completely remove the information of this breakpoint
	// when now the same address is reached then breakpoint should not be reached
	// add the error cases 
		// when not found 
		// if remove breakpoint is called on a function that is currently active on the call stack of the debugee's process, 
		// and the set_enable flag is set as 1, then remove the breakpoint, should return -1

	if(ctx == NULL) return -1;
	if(ctx->dbg == NULL) return -1;
	if(addr == NULL) return -1;
	
	struct breakpoint_info* head = ctx->dbg->head;
	
	while(head != NULL){
		if(head->addr == (u64) addr){
			break;
		}
		head = head->next;
	}

	if(head == NULL) return -1;

	// check if the function is already on the stack, and if it is already on the stack and do set enable is 1, then retunrn -1
	int present = presentOnStack((u64)addr, ctx);
	
	if(present && head->end_breakpoint_enable == 1){
		return -1;
	}

	*(unsigned char *)addr = PUSHRBP_OPCODE;
	
	if(ctx->dbg->head == head){
		ctx->dbg->head = head->next;
		head->next = NULL;
		free_breakpoint_info(head);
	}
	else {
		struct breakpoint_info* prev = ctx->dbg->head;
		while(prev->next != head){
			prev = prev->next;
		}
		prev->next = head->next;
		head->next = NULL;
		free_breakpoint_info(head);
	}
	ctx->dbg->set_break_count--;
	return 0;
}


/*
 * called from debuggers context
 */

int do_info_breakpoints(struct exec_context *ctx, struct breakpoint *ubp)
{
	
	// Your code
	if(ctx == NULL || ctx->dbg == NULL) return -1;

	struct breakpoint_info *head = ctx->dbg->head;
	int i = 0;
	while(head != NULL){
		struct breakpoint curr;
		ubp[i] = curr;
		ubp[i].addr = head->addr;
		ubp[i].end_breakpoint_enable = head->end_breakpoint_enable;
		ubp[i].num = head->num + 1;
		i++;	
		head = head->next;
	}
	return ctx->dbg->set_break_count;
}


/*
 * called from debuggers context
 */
int do_info_registers(struct exec_context *ctx, struct registers *regs)
{
	// Your code
	if(ctx == NULL || ctx->dbg == NULL){
		return -1;
	}
	*regs = ctx->dbg->regs;
	return 0;
}

/*
 * Called from debuggers context
 */
int do_backtrace(struct exec_context *ctx, u64 bt_buf)
{

	// Your code
	if(ctx == NULL || ctx->dbg == NULL) return -1;

	u64* arrayAddr = (u64 *)bt_buf;	
	for(int i = 0;i<ctx->dbg->backTraceCount;i++){
		arrayAddr[i] = ctx->dbg->backtraceArray[i];
	}
	return ctx->dbg->backTraceCount;
}

/*
 * When the debugger calls wait
 * it must move to WAITING state
 * and its child must move to READY state
 */

s64 do_wait_and_continue(struct exec_context *ctx)
{
	if(ctx == NULL || ctx->dbg == NULL){
		return -1;
	}
	// Your code
	struct exec_context *childCTX = NULL;
	for(int i = 0;i<MAX_PROCESSES;i++){
		childCTX = get_ctx_by_pid(i);
		if(childCTX->ppid == ctx->pid){
			break;
		}
	}
	

	if(childCTX == NULL){
		// printk("CHILD CTX is NULL ############\n");
		return CHILD_EXIT;
	}
	if(childCTX->ppid != ctx->pid){
		// printk("CHILD CTX is NULL ############\n");
		return CHILD_EXIT;
	}

	childCTX->state = READY;
	ctx->state = WAITING;
	schedule(childCTX);
	return -1;
}






